20/SEP/1999
This README file is to accompany the following file:

  cirthh1b.zip    Help file for Cirth Erebor font packs for Windows (version 1.1)
                  in Adobe's Portable Document Format (PDF).

  �copyright - 1999 - Daniel Steven Smith
  fontmaster@geocities.com 
  http://www.geocities.com/TimesSquare/4948/index.html



What files are in this ZIP file:
--------------------------------------------------------------------------------
CIRTHHELP.PDF ... Source file for Dan Smith's "Cirth Erebor Font packs for 
                  Windows" (version 1.1) Help file in PDF Format. 
READ-ME.TXT ..... This file.



What is this file:
--------------------------------------------------------------------------------
This ZIP archive contains the source file for Dan Smith's "Cirth Erebor" Help 
file for Windows.  It explains how these fonts can be used to write Elf, 
Dwarf and Human language inscriptions using the Cirth alphabet of Middle-earth 
with Windows applications.  (The Cirth alphabet was devised by J.R.R. Tolkien 
and sometimes used by natives of Middle-earth.) 

This Help file is Postcard-ware.  If you like this Help file, please send me a 
postcard or letter (using an attractive or interesting stamp). If you supply me 
with your email address, I'll try to write back. You can get my current postal 
address by visiting my WWW home page (listed above).  If you do write, please 
tell me of your Cirth writing interests.  

This Help file cannot be sold for a profit.  (Although, if you really enjoy 
using this Help file and need to find some financial way of showing your 
appreciation, any and all donations will be gladly accepted.)  CD-ROM and 
Shareware distributors are required to notify me before distributing this Help 
file.

This Help file may be used for any personal, private or non-commercial 
publication.  

This Help file may NOT be used in any commercial product or publication without 
my permission and the direct consent of the Tolkien Estate.  

How do I get this file to work:
--------------------------------------------------------------------------------
1) Un-Zip the "cirthh11b.zip" file into a Temporary directory. 
   (Visit: www.winzip.com to download an un-zipping program, if necessary.) 
2) Use Adobe Acrobat Reader to open the *.pdf files.
   (Visit: www.adobe.com to download the Adobe Acrobat Reader, if necessary.)

Note: This Cirth Help file will make no sense unless you have already 
installed my Cirth font packs for Windows: "Cirth Erebor".  It can be 
downloaded from:
  http://www.geocities.com/TimesSquare/4948/index.html

